const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const ACCESS_KEY = process.env.ACCESS_KEY || '';
const ADMIN_KEY = process.env.ADMIN_KEY || '';
const AI_API_KEY = process.env.AI_API_KEY || '';
const AI_MODEL = process.env.AI_MODEL || 'gpt-4o-mini';

function send(res, status, data, type='application/json') {
  res.writeHead(status, {'Content-Type': type, 'X-Content-Type-Options':'nosniff'});
  res.end(type.includes('json') ? JSON.stringify(data) : data);
}
function body(req) {
  return new Promise((resolve,reject)=>{
    let raw=''; req.on('data',c=>{raw+=c;if(raw.length>20000) req.destroy()});
    req.on('end',()=>{try{resolve(JSON.parse(raw||'{}'))}catch(e){reject(e)}});
    req.on('error',reject);
  });
}
const server = http.createServer(async (req,res)=>{
  try {
    if(req.method==='POST' && req.url==='/api/unlock') {
      const b=await body(req);
      if(!ACCESS_KEY) return send(res,503,{error:'Access key has not been configured by the site owner.'});
      return send(res,b.key===ACCESS_KEY?200:401,b.key===ACCESS_KEY?{ok:true}:{error:'Invalid access key'});
    }
    if(req.method==='POST' && req.url==='/api/admin/check') {
      const b=await body(req);
      if(!ADMIN_KEY) return send(res,503,{error:'Admin key has not been configured.'});
      return send(res,b.key===ADMIN_KEY?200:401,b.key===ADMIN_KEY?{ok:true}:{error:'Incorrect admin key'});
    }
    if(req.method==='POST' && req.url==='/api/chat') {
      const b=await body(req);
      if(!AI_API_KEY) return send(res,503,{error:'Real AI is not configured yet. The site owner must add an AI API key on the server.'});
      if(typeof b.message!=='string' || !b.message.trim()) return send(res,400,{error:'Please enter a message.'});
      const upstream=await fetch('https://api.openai.com/v1/chat/completions',{
        method:'POST',headers:{'Authorization':`Bearer ${AI_API_KEY}`,'Content-Type':'application/json'},
        body:JSON.stringify({model:AI_MODEL,messages:[{role:'user',content:b.message.slice(0,4000)}]})
      });
      const data=await upstream.json();
      if(!upstream.ok) return send(res,502,{error:data.error?.message||'AI provider request failed.'});
      return send(res,200,{reply:data.choices?.[0]?.message?.content||'No reply received.'});
    }
    if(req.method==='GET' && (req.url==='/' || req.url==='/index.html')) {
      return send(res,200,fs.readFileSync(path.join(__dirname,'index.html'),'utf8'),'text/html; charset=utf-8');
    }
    return send(res,404,{error:'Not found'});
  } catch(e) { return send(res,500,{error:'Server error'}); }
});
server.listen(PORT,()=>console.log(`CHIKKU PANEL running on port ${PORT}`));
