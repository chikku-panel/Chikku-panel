# CHIKKU PANEL

A mobile-friendly starter website with:
- Access-key check handled by the server
- Happ APK link to the GitHub release URL supplied by the site owner
- AI chat endpoint (requires a server-side API key)
- Admin-key verification endpoint

## Run locally
1. Install Node.js 18 or newer.
2. Copy `.env.example` to `.env` and fill in your own values.
3. Install a dotenv loader if you want `.env` support, or set the environment variables in your terminal/hosting dashboard.
4. Run `npm start`.
5. Open `http://localhost:3000`.

This starter does not include a database, user accounts, payment system, or a full admin dashboard yet. The unlock status in the browser is only a front-end convenience; protect every private API route server-side before using this for real users.

## Important
- Never put AI API keys or admin secrets in `index.html` or public JavaScript.
- AI API usage may cost money. Get permission from the account owner before adding billing details or creating API keys.
- Use a unique access key and admin key. Do not share the admin key with users.
- The Happ link opens the GitHub release download supplied by the site owner. Verify the publisher and file before installing an APK.
